import React from 'react';
import TaskInput from '../molecules/TaskInput';
import TaskList from '../organisms/TaskList';
import { useDispatch, useSelector } from 'react-redux';
import './ToDoTemplate.scss';

const ToDoTemplate = () => {
  const tasks = useSelector((state) => state.tasks);
  const dispatch = useDispatch();

  const addTask = (taskText) => {
    dispatch({ type: 'ADD_TASK', payload: taskText });
  };

  const toggleComplete = (index) => {
    dispatch({ type: 'TOGGLE_TASK', index });
  };

  const deleteTask = (index) => {
    dispatch({ type: 'DELETE_TASK', index });
  };

  return (
    <div className="todo-template">
      <h1>Todo List</h1>
      <TaskInput addTask={addTask} />
      <TaskList tasks={tasks} toggleComplete={toggleComplete} deleteTask={deleteTask} />
    </div>
  );
};

export default ToDoTemplate;