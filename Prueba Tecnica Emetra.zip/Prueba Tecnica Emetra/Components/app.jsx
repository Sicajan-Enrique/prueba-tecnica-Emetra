import React from 'react';
import ToDoTemplate from './components/templates/ToDoTemplate';
import './App.scss';

const App = () => {
  return (
    <div className="App">
      <ToDoTemplate />
    </div>
  );
};

export default App;