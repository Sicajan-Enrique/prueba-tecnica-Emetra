import React from 'react';
import './TaskList.scss';
import Button from '../atoms/Button';

const TaskList = ({ tasks, toggleComplete, deleteTask }) => (
  <ul className="task-list">
    {tasks.map((task, index) => (
      <li key={index} className={task.completed ? 'completed' : ''}>
        <span onClick={() => toggleComplete(index)}>
          {task.text}
        </span>
        <Button text="Delete" onClick={() => deleteTask(index)} />
      </li>
    ))}
  </ul>
);

export default TaskList;