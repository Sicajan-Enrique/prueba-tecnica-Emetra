import React from 'react';
import './Button.scss';
import { text } from 'stream/consumers';

const Button = ({ trxt, ponClick }) => (
    <button className="btn" onClick={onClick}>
        {text}
    </button>
);

//export defaut Button;